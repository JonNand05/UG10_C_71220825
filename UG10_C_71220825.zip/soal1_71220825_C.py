


print("kalkulator sederhana")
print("1. tambah")
print("2. kurang")
print("3. kali")
print("4. bagi")


int(input("masukan angkapertama: "))
int(input("masukan angkakedua: "))
Menu=input("Masukan Pilihan :")

if Menu =="1":
     tambah = angkapertama+angkakedua
     print(tambah)
elif Menu =="2":
     kurang  = angkapertama-angkakedua
     print(kurang)
elif Menu =="3":
     kali  = angkapertama*angkakedua
     print(kali)
elif Menu =="4":
     bagi  = angkapertama/angkakedua
     print(bagi)
    






