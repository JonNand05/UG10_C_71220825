
menu =input("Masukan daftar pesanan: eskrim, esteh, putih")
print("Daftar pesanan:['Eskrim','Es Teh','Putih']")
int(input("Masukan pesanan yang ingin ditambahkan :"))
if (int== ayamgoreng):
    print ("Eskrim,Es Teh, Ayam goreng")

elif (int== putih):
    print ("PUTIH sudah berada dalam daftar pesanan")
