

Bulan= int(input("Masukkan bulan (1-12):"))
if (Bulan == 1):
    Hari  = 31
    print ("Jumlah hari : 31")
elif (Bulan == 2):
    Hari = 28
    print ("Jumlah hari : 28")
elif (Bulan == 3):
    Hari = 31
    print ("Jumlah hari : 31")
elif (Bulan == 4):
    Hari = 30
    print ("Jumlah hari : 30")
elif (Bulan == 5):
    Hari = 31
    print ("Jumlah hari : 31")
elif (Bulan == 6):
    Hari = 30
    print ("Jumlah hari : 30")
elif (Bulan == 7):
    Hari = 31
    print ("Jumlah hari : 31")
elif (Bulan == 8):
    Hari = 31
    print ("Jumlah hari : 31")
elif (Bulan == 9):
    Hari = 30
    print ("Jumlah hari : 30")
elif (Bulan == 10):
    Hari = 31
    print ("Jumlah hari : 31")
elif (Bulan == 11):
    Hari = 30
    print ("Jumlah hari : 30")
elif (Bulan == 12):
    Hari = 31
    print ("Jumlah hari : 31")
